package com.litham.nukhba;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
final class SrtTest {
    public static void main(String[] args) throws Exception {
        List<Cue> cues = Arrays.asList(new Cue(0, 2390, "مرحباً بالعالم"),new Cue(2500, 4000, "كيف حالكم؟"));
        String srt = Srt.write(cues);
        List<Cue> parsed = Srt.read(new ByteArrayInputStream(srt.getBytes(StandardCharsets.UTF_8)));
        if (parsed.size() != 2 || parsed.get(0).startMs != 0 || parsed.get(1).endMs != 4000
            || !parsed.get(1).text.equals("كيف حالكم؟")) throw new AssertionError("SRT round-trip failed");
        String srt2 = "\uFEFF1\r\n00:00:01,234 --> 00:00:02,900\r\nأهلاً\r\n\r\n";
        List<Cue> parsed2 = Srt.read(new ByteArrayInputStream(srt2.getBytes(StandardCharsets.UTF_8)));
        if (parsed2.size() != 1 || parsed2.get(0).startMs != 1234) throw new AssertionError("SRT BOM failed");
        System.out.println("SrtTest: PASS");
    }
}
