package com.litham.nukhba;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

final class Srt {
    private static final Pattern TIME = Pattern.compile("(\\d{1,3}):(\\d{2}):(\\d{2})[,\\.](\\d{1,3})");
    private static final Pattern LINE = Pattern.compile("\\s*(\\d{1,3}:\\d{2}:\\d{2}[,\\.]\\d{1,3})\\s*-->\\s*(\\d{1,3}:\\d{2}:\\d{2}[,\\.]\\d{1,3}).*");
    static List<Cue> read(InputStream in) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            List<Cue> cues = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                Matcher m = LINE.matcher(line.replace("\uFEFF", ""));
                if (!m.matches()) continue;
                long start = parseTime(m.group(1)), end = parseTime(m.group(2));
                StringBuilder sb = new StringBuilder();
                while ((line = reader.readLine()) != null && !line.trim().isEmpty()) {
                    if (sb.length() > 0) sb.append('\n');
                    sb.append(line.trim());
                }
                cues.add(new Cue(start, end, sb.toString()));
            }
            cues.sort(Comparator.comparingLong(c -> c.startMs));
            return cues;
        }
    }
    static String write(List<Cue> cues) {
        StringBuilder out = new StringBuilder();
        int count = 1;
        for (Cue c : cues) {
            if (c.text.isEmpty()) continue;
            out.append(count++).append('\n').append(time(c.startMs)).append(" --> ")
                    .append(time(c.endMs)).append('\n').append(c.text).append("\n\n");
        }
        return out.toString();
    }
    private static long parseTime(String s) {
        Matcher m = TIME.matcher(s);
        if (!m.matches()) return 0;
        int mill = Integer.parseInt(m.group(4));
        if (m.group(4).length() == 1) mill *= 100;
        else if (m.group(4).length() == 2) mill *= 10;
        return ((Integer.parseInt(m.group(1))*3600L + Integer.parseInt(m.group(2))*60L
                + Integer.parseInt(m.group(3))) * 1000L) + mill;
    }
    static String time(long ms) {
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", ms/3600000, ms/60000%60, ms/1000%60, ms%1000);
    }
    static void save(File file, List<Cue> cues) throws IOException {
        try (OutputStream out = new FileOutputStream(file)) {
            out.write(write(cues).getBytes(StandardCharsets.UTF_8));
        }
    }
}
