package com.litham.nukhba;

final class Cue {
    final long startMs, endMs;
    final String text;
    Cue(long startMs, long endMs, String text) {
        this.startMs = Math.max(0, startMs);
        this.endMs = Math.max(this.startMs + 100, endMs);
        this.text = text == null ? "" : text.trim();
    }
}
