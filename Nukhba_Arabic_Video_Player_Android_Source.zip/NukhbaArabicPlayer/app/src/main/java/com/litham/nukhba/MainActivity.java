package com.litham.nukhba;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Native Android video player; accepts external ACTION_VIEW/ACTION_SEND video intents.
 *  Subtitles are displayed locally and synced to video position, not burned into video.
 */
public final class MainActivity extends Activity {
    private static final int PICK_VIDEO = 101, PICK_SRT = 102, SAVE_SRT = 103;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Cue> cues = new ArrayList<>();
    private VideoView video;
    private TextView subtitle, status, timeline, placeholder;
    private SeekBar seek;
    private Button playButton;
    private LinearLayout topBar, bottomBar;
    private Uri currentUri;
    private String videoName = "فيلم";
    private boolean seeking = false, fullScreen = false, translating = false;
    private int generation = 0;
    private Thread workThread;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (video != null && currentUri != null) {
                try {
                    int position = video.getCurrentPosition(), duration = video.getDuration();
                    if (!seeking && duration > 0) seek.setProgress((int)(1000L * position / duration));
                    timeline.setText(clock(position) + " / " + clock(Math.max(0,duration)));
                    playButton.setText(video.isPlaying() ? "❚❚" : "▶");
                    showCue(position);
                } catch (Exception ignored) { }
            }
            handler.postDelayed(this, 180);
        }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(10,16,25));
        getWindow().setNavigationBarColor(Color.rgb(10,16,25));
        buildInterface();
        handler.post(ticker);
        readExternalIntent(getIntent());
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        readExternalIntent(intent);
    }
    @Override protected void onDestroy() {
        generation++;
        if (workThread != null) workThread.interrupt();
        handler.removeCallbacks(ticker);
        super.onDestroy();
    }
    private SharedPreferences prefs() { return getSharedPreferences("nukhba", MODE_PRIVATE); }
    private int dp(int a) { return (int)(a * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String content, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(content); t.setTextColor(color); t.setTextSize(sp); t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }
    private Button button(String content, Runnable action) {
        Button b = new Button(this);
        b.setText(content);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(33,58,79)));
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private void buildInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(9,14,22));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(root);

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.VERTICAL);
        topBar.setPadding(dp(9), dp(6), dp(9), dp(5));
        topBar.setBackgroundColor(Color.rgb(16,27,41));
        TextView heading = text("مشغّل النخبة  •  ترجمة عربية للأفلام", 17, 0xFFF2D18C);
        heading.setGravity(Gravity.CENTER);
        topBar.addView(heading, new LinearLayout.LayoutParams(-1, dp(41)));
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.HORIZONTAL);
        menu.addView(button("فتح فيلم", this::pickVideo));
        menu.addView(button("ترجمة للعربية", this::startTranslation));
        menu.addView(button("إعدادات", this::settings));
        menu.addView(button("فتح SRT", this::pickSrt));
        menu.addView(button("حفظ SRT", this::saveSrt));
        menu.addView(button("حجم الخط", this::fontDialog));
        scroll.addView(menu);
        topBar.addView(scroll, new LinearLayout.LayoutParams(-1, dp(55)));
        root.addView(topBar);

        FrameLayout stage = new FrameLayout(this);
        stage.setBackgroundColor(Color.BLACK);
        video = new VideoView(this);
        stage.addView(video, new FrameLayout.LayoutParams(-1, -1));
        placeholder = text("افتح فيلماً من جهازك أو شاركه مع مشغّل النخبة\n\nالترجمة العربية تظهر هنا أسفل الفيلم", 18, 0xFFB5C4D3);
        placeholder.setGravity(Gravity.CENTER);
        placeholder.setPadding(dp(20),dp(20),dp(20),dp(20));
        stage.addView(placeholder, new FrameLayout.LayoutParams(-1, -1));
        subtitle = text("", 23, Color.WHITE);
        subtitle.setTextDirection(View.TEXT_DIRECTION_RTL);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setBackgroundColor(0x97000000);
        subtitle.setPadding(dp(12), dp(4), dp(12), dp(4));
        subtitle.setShadowLayer(3f,1f,2f,Color.BLACK);
        subtitle.setVisibility(View.GONE);
        FrameLayout.LayoutParams subtitleParams = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        subtitleParams.setMargins(dp(12),dp(6),dp(12),dp(36));
        stage.addView(subtitle, subtitleParams);
        root.addView(stage, new LinearLayout.LayoutParams(-1, 0, 1f));
        video.setOnPreparedListener(mp -> {
            if (currentUri == null) return;
            video.start();
            placeholder.setVisibility(View.GONE);
            setStatus("يعمل الآن: " + videoName);
            if (prefs().getBoolean("auto_translate", false) && cues.isEmpty()) startTranslation();
        });
        video.setOnErrorListener((mp, what, extra) -> {
            placeholder.setVisibility(View.VISIBLE);
            setStatus("لم يتمكن مشغل النظام من فتح هذا الفيديو. جرّب ملف MP4 بصيغة H.264/AAC.");
            return true;
        });
        video.setOnCompletionListener(mp -> playButton.setText("▶"));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        bottomBar.setPadding(dp(12),dp(4),dp(12),dp(8));
        bottomBar.setBackgroundColor(Color.rgb(16,27,41));
        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        playButton = button("▶", () -> {
            if (currentUri == null) { pickVideo(); return; }
            if (video.isPlaying()) video.pause(); else video.start();
        });
        controls.addView(playButton);
        seek = new SeekBar(this);
        seek.setMax(1000);
        controls.addView(seek, new LinearLayout.LayoutParams(0, dp(48), 1f));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) { }
            @Override public void onStartTrackingTouch(SeekBar s) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                if (video != null && currentUri != null && video.getDuration() > 0)
                    video.seekTo((int)((long)s.getProgress() * video.getDuration() / 1000L));
                seeking = false;
            }
        });
        controls.addView(button("⛶", this::toggleFullScreen));
        bottomBar.addView(controls);
        timeline = text("00:00 / 00:00",12,0xFFB4C7D7);
        timeline.setGravity(Gravity.CENTER);
        bottomBar.addView(timeline);
        status = text("جاهز — اختر فيلماً من جهازك أو من تطبيق آخر", 12, 0xFFF2D18C);
        status.setGravity(Gravity.CENTER);
        status.setMaxLines(3);
        bottomBar.addView(status, new LinearLayout.LayoutParams(-1, dp(42)));
        root.addView(bottomBar);
    }
    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_VIDEO);
    }
    private void pickSrt() {
        if (currentUri == null) { toast("افتح الفيلم أولاً"); return; }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/x-subrip","text/plain","application/octet-stream"});
        startActivityForResult(intent, PICK_SRT);
    }
    private void saveSrt() {
        if (cues.isEmpty()) { toast("لا توجد ترجمة للحفظ بعد"); return; }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, videoName.replaceAll("[^\\p{L}\\p{N}._ -]", "_") + "_AR.srt");
        startActivityForResult(intent, SAVE_SRT);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (request == PICK_VIDEO) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch (SecurityException ignored) { }
                loadVideo(uri);
            } else if (request == PICK_SRT) {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("تعذر فتح ملف الترجمة");
                    List<Cue> loaded = Srt.read(in);
                    if (loaded.isEmpty()) throw new IOException("ملف SRT فارغ أو غير صحيح");
                    cues.clear(); cues.addAll(loaded);
                    Srt.save(cacheFile(), cues);
                    showCue(video.getCurrentPosition());
                    setStatus("تم تحميل " + cues.size() + " سطراً من الترجمة العربية");
                }
            } else if (request == SAVE_SRT) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("تعذر حفظ الملف");
                    out.write(Srt.write(cues).getBytes(StandardCharsets.UTF_8));
                }
                toast("تم حفظ ملف الترجمة SRT");
            }
        } catch (Exception e) { error(e.getMessage()); }
    }
    private void readExternalIntent(Intent intent) {
        if (intent == null) return;
        Uri uri = null;
        if (Intent.ACTION_VIEW.equals(intent.getAction())) uri = intent.getData();
        else if (Intent.ACTION_SEND.equals(intent.getAction())) {
            Object value = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (value instanceof Uri) uri = (Uri) value;
            if (uri == null && intent.getClipData() != null && intent.getClipData().getItemCount() > 0)
                uri = intent.getClipData().getItemAt(0).getUri();
        }
        if (uri != null) loadVideo(uri);
    }
    private void loadVideo(Uri uri) {
        generation++;
        if (workThread != null) workThread.interrupt();
        translating = false;
        currentUri = uri;
        videoName = nameOf(uri);
        cues.clear();
        seek.setProgress(0);
        subtitle.setVisibility(View.GONE);
        try {
            File cached = cacheFile();
            if (cached.isFile()) {
                try (InputStream in = new FileInputStream(cached)) { cues.addAll(Srt.read(in)); }
            }
            video.setVideoURI(uri);
            video.requestFocus();
            placeholder.setVisibility(View.VISIBLE);
            setStatus(cues.isEmpty() ? "يتم فتح: " + videoName : "تم تحميل الترجمة المحفوظة: " + videoName);
        } catch (Exception e) { error("تعذر فتح الملف: " + e.getMessage()); }
    }
    private String nameOf(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        return uri.getLastPathSegment() == null ? "فيلم" : uri.getLastPathSegment();
    }
    private File cacheFile() {
        if (currentUri == null) throw new IllegalStateException("لم يتم اختيار فيلم");
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(currentUri.toString().getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < 20; i++) hex.append(String.format(Locale.US, "%02x", digest[i] & 0xff));
            File dir = new File(getFilesDir(), "translations");
            if (!dir.exists()) dir.mkdirs();
            return new File(dir, hex + ".srt");
        } catch (Exception e) { throw new RuntimeException(e); }
    }
    private void startTranslation() {
        if (currentUri == null) { toast("اختر فيلماً أولاً"); return; }
        if (translating) { toast("الترجمة قيد التنفيذ"); return; }
        String key = SecureKey.load(this);
        if (key.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("مفتاح خدمة الترجمة مطلوب")
                    .setMessage("الترجمة التلقائية تستخدم خدمة OpenAI API المدفوعة بشكل مستقل عن اشتراك ChatGPT. أدخل مفتاحك في الإعدادات. يمكنك فتح SRT دون مفتاح.")
                    .setPositiveButton("الإعدادات", (d,w) -> settings()).setNegativeButton("إلغاء", null).show();
            return;
        }
        final Uri source = currentUri;
        final int job = ++generation;
        translating = true;
        cues.clear();
        subtitle.setVisibility(View.GONE);
        workThread = new Thread(() -> {
            try {
                List<Cue> result = CloudTranslator.translate(this, source, key, new CloudTranslator.Progress() {
                    @Override public void status(String message) {
                        runOnUiThread(() -> { if (job == generation) setStatus(message); });
                    }
                    @Override public void update(List<Cue> translated) {
                        runOnUiThread(() -> {
                            if (job != generation) return;
                            cues.clear(); cues.addAll(translated);
                            showCue(video.getCurrentPosition());
                        });
                    }
                });
                runOnUiThread(() -> {
                    if (job != generation) return;
                    translating = false;
                    cues.clear(); cues.addAll(result);
                    try { Srt.save(cacheFile(), cues); }
                    catch (Exception e) { setStatus("تمت الترجمة لكن تعذر حفظها: " + e.getMessage()); return; }
                    setStatus("اكتملت الترجمة العربية: " + cues.size() + " سطراً، وحُفظت على الهاتف");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (job != generation) return;
                    translating = false;
                    error("تعذرت الترجمة: " + e.getMessage());
                });
            }
        }, "nukhba-translation");
        workThread.start();
    }
    private void settings() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(10), dp(18), dp(4));
        TextView hint = text("أدخل مفتاح OpenAI API الخاص بك داخل التطبيق فقط. سيُرفع صوت الفيلم إلى OpenAI لتفريغه وترجمته؛ لا يُرفع الفيديو نفسه. قد تُحسب رسوم حسب الاستعمال. مفتاح API منفصل عن اشتراك ChatGPT.", 14, Color.DKGRAY);
        layout.addView(hint);
        EditText entry = new EditText(this);
        entry.setSingleLine(true);
        entry.setTextDirection(View.TEXT_DIRECTION_LTR);
        entry.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        entry.setHint(SecureKey.load(this).isEmpty() ? "sk-..." : "مفتاح محفوظ — اتركه فارغاً للإبقاء عليه");
        layout.addView(entry);
        CheckBox auto = new CheckBox(this);
        auto.setText("ترجمة الأفلام تلقائياً عند فتحها (يرسل صوت الفيلم للخدمة)");
        auto.setChecked(prefs().getBoolean("auto_translate", false));
        layout.addView(auto);
        new AlertDialog.Builder(this).setTitle("إعداد الترجمة")
                .setView(layout)
                .setPositiveButton("حفظ", (d,w) -> {
                    try {
                        String provided = entry.getText().toString().trim();
                        if (!provided.isEmpty()) SecureKey.save(this, provided);
                        prefs().edit().putBoolean("auto_translate", auto.isChecked()).apply();
                        toast("تم حفظ الإعدادات");
                    } catch (Exception e) { error("تعذر حفظ مفتاح الخدمة: " + e.getMessage()); }
                })
                .setNeutralButton("حذف المفتاح", (d,w) -> {
                    try { SecureKey.save(this, ""); prefs().edit().putBoolean("auto_translate", false).apply(); toast("تم حذف المفتاح من التطبيق"); }
                    catch (Exception e) { error(e.getMessage()); }
                })
                .setNegativeButton("إلغاء", null).show();
    }
    private void fontDialog() {
        String[] size = {"صغير", "متوسط", "كبير", "كبير جداً"};
        int[] sizes = {18, 22, 27, 33};
        new AlertDialog.Builder(this).setTitle("حجم الترجمة")
                .setSingleChoiceItems(size, 1, (d, choice) -> {
                    subtitle.setTextSize(sizes[choice]);
                    prefs().edit().putInt("font_size", sizes[choice]).apply();
                    d.dismiss();
                }).setNegativeButton("إغلاق",null).show();
    }
    private void toggleFullScreen() {
        fullScreen = !fullScreen;
        topBar.setVisibility(fullScreen ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(fullScreen ? View.GONE : View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(fullScreen
                ? View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                : View.SYSTEM_UI_FLAG_VISIBLE);
        if (fullScreen) video.setOnClickListener(v -> toggleFullScreen());
        else video.setOnClickListener(null);
    }
    private void showCue(int positionMs) {
        String result = "";
        int lo = 0, hi = cues.size() - 1, idx = -1;
        while (lo <= hi) {
            int middle = (lo + hi) >>> 1;
            if (cues.get(middle).startMs <= positionMs) { idx = middle; lo = middle + 1; }
            else hi = middle - 1;
        }
        if (idx >= 0) {
            Cue candidate = cues.get(idx);
            if (positionMs <= candidate.endMs) result = candidate.text;
        }
        if (result.isEmpty()) subtitle.setVisibility(View.GONE);
        else {
            subtitle.setText(result);
            subtitle.setTextSize(prefs().getInt("font_size", 23));
            subtitle.setVisibility(View.VISIBLE);
        }
    }
    private String clock(long milliseconds) {
        long s = Math.max(0, milliseconds / 1000);
        return String.format(Locale.US, "%02d:%02d%s", s / 60 % 60, s % 60,
                s >= 3600 ? " (" + (s / 3600) + "س)" : "");
    }
    private void setStatus(String message) { status.setText(message); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    private void error(String message) { setStatus(message); toast(message); }
}
