package com.litham.nukhba;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * BYOK translation pipeline. Sends only extracted AAC audio, never video frames.
 * Whisper-1 returns timed segments; gpt-4o-mini translates the text to Arabic.
 * A separate paid OpenAI API key is required. Must run off the UI thread.
 */
final class CloudTranslator {
    interface Progress {
        void status(String message);
        void update(List<Cue> translated);
    }

    static List<Cue> translate(Context ctx, Uri uri, String apiKey, Progress progress) throws Exception {
        File working = new File(ctx.getCacheDir(), "speech_" + System.nanoTime());
        List<Cue> finalCues = new ArrayList<>();
        try {
            progress.status("استخراج الصوت فقط من الفيديو...");
            List<AudioChunker.Part> chunks = AudioChunker.split(ctx, uri, working);
            for (int p = 0; p < chunks.size(); p++) {
                if (Thread.currentThread().isInterrupted()) throw new InterruptedException("تم إيقاف الترجمة");
                AudioChunker.Part part = chunks.get(p);
                progress.status("التعرف على الكلام: المقطع " + (p + 1) + " من " + chunks.size());
                JSONObject result = transcribe(part.file, apiKey);
                JSONArray segments = result.optJSONArray("segments");
                if (segments == null) throw new IOException("لم تُرجع خدمة التفريغ توقيت الجمل");
                List<Cue> original = new ArrayList<>();
                for (int i = 0; i < segments.length(); i++) {
                    JSONObject s = segments.getJSONObject(i);
                    String words = s.optString("text", "").trim();
                    if (words.isEmpty()) continue;
                    long offsetMs = part.startUs / 1000;
                    long start = offsetMs + Math.round(s.optDouble("start", 0) * 1000);
                    long end = offsetMs + Math.round(s.optDouble("end", 0) * 1000);
                    original.add(new Cue(start, end, words));
                }
                for (int begin = 0; begin < original.size(); begin += 35) {
                    if (Thread.currentThread().isInterrupted()) throw new InterruptedException("تم إيقاف الترجمة");
                    int end = Math.min(begin + 35, original.size());
                    progress.status("الترجمة للعربية: المقطع " + (p + 1) + " من " + chunks.size());
                    List<Cue> input = original.subList(begin, end);
                    finalCues.addAll(translateBatch(input, apiKey));
                    finalCues.sort(Comparator.comparingLong(c -> c.startMs));
                    progress.update(new ArrayList<>(finalCues));
                }
                part.file.delete();
            }
            return finalCues;
        } finally {
            File[] remaining = working.listFiles();
            if (remaining != null) for (File f : remaining) f.delete();
            working.delete();
        }
    }

    private static JSONObject transcribe(File file, String apiKey) throws Exception {
        if (file.length() > 24_000_000L) throw new IOException("ملف الصوت أكبر من حد الرفع");
        String boundary = "NukhbaBoundary" + Long.toHexString(System.nanoTime());
        HttpURLConnection conn = connection("https://api.openai.com/v1/audio/transcriptions", apiKey);
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        conn.setDoOutput(true);
        conn.setChunkedStreamingMode(32768);
        try {
            try (OutputStream out = new BufferedOutputStream(conn.getOutputStream())) {
                field(out, boundary, "model", "whisper-1");
                field(out, boundary, "response_format", "verbose_json");
                field(out, boundary, "timestamp_granularities[]", "segment");
                bytes(out, "--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.m4a\"\r\nContent-Type: audio/mp4\r\n\r\n");
                try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
                    byte[] buf = new byte[32768];
                    int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
                bytes(out, "\r\n--" + boundary + "--\r\n");
            }
            return new JSONObject(readResponse(conn));
        } finally { conn.disconnect(); }
    }

    private static List<Cue> translateBatch(List<Cue> original, String apiKey) throws Exception {
        JSONArray sentences = new JSONArray();
        for (int i = 0; i < original.size(); i++) {
            JSONObject item = new JSONObject();
            item.put("i", i);
            item.put("text", original.get(i).text);
            sentences.put(item);
        }
        JSONObject body = new JSONObject();
        body.put("model", "gpt-4o-mini");
        body.put("temperature", 0.2);
        body.put("response_format", new JSONObject().put("type", "json_object"));
        JSONArray messages = new JSONArray();
        messages.put(new JSONObject().put("role", "system").put("content",
            "Translate each subtitle's dialogue to clear, concise Modern Standard Arabic. " +
            "Keep proper names, preserve meaning and order. " +
            "Return JSON ONLY: {\"translations\":[{\"i\":0,\"ar\":\"...\"}]} " +
            "with exactly one translation for every supplied i. No commentary or timings."));
        messages.put(new JSONObject().put("role", "user").put("content", sentences.toString()));
        body.put("messages", messages);
        HttpURLConnection conn = connection("https://api.openai.com/v1/chat/completions", apiKey);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setDoOutput(true);
        try {
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(data.length);
            try (OutputStream out = conn.getOutputStream()) { out.write(data); }
            JSONObject response = new JSONObject(readResponse(conn));
            String content = response.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content");
            JSONArray translations = new JSONObject(content).getJSONArray("translations");
            Map<Integer, String> mapping = new HashMap<>();
            for (int j = 0; j < translations.length(); j++) {
                JSONObject obj = translations.getJSONObject(j);
                mapping.put(obj.getInt("i"), obj.optString("ar", ""));
            }
            List<Cue> out = new ArrayList<>();
            for (int i = 0; i < original.size(); i++) {
                String ar = mapping.get(i);
                if (ar == null || ar.trim().isEmpty()) {
                    throw new IOException("لم تكتمل ترجمة الجمل؛ يُرجى إعادة المحاولة");
                }
                Cue old = original.get(i);
                out.add(new Cue(old.startMs, old.endMs, ar));
            }
            return out;
        } finally { conn.disconnect(); }
    }

    private static HttpURLConnection connection(String uri, String key) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(uri).openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + key);
        conn.setRequestProperty("Accept", "application/json");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(180000);
        return conn;
    }
    private static String readResponse(HttpURLConnection conn) throws IOException {
        int status = conn.getResponseCode();
        InputStream stream = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
        if (stream == null) throw new IOException("تعذر الاتصال بخدمة الترجمة (" + status + ")");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream input = stream) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = input.read(buf)) != -1) {
                out.write(buf, 0, n);
                if (out.size() > 10_000_000) throw new IOException("استجابة كبيرة جداً من الخادم");
            }
        }
        String message = out.toString(StandardCharsets.UTF_8.name());
        if (status < 200 || status >= 300) {
            String reason;
            try { reason = new JSONObject(message).getJSONObject("error").optString("message", "خدمة غير متاحة"); }
            catch (Exception ignored) { reason = "استجابة غير متوقعة"; }
            throw new IOException("خطأ خدمة الترجمة (" + status + "): " + reason);
        }
        return message;
    }
    private static void field(OutputStream out, String boundary, String name, String value) throws IOException {
        bytes(out, "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + value + "\r\n");
    }
    private static void bytes(OutputStream out, String text) throws IOException {
        out.write(text.getBytes(StandardCharsets.UTF_8));
    }
}
