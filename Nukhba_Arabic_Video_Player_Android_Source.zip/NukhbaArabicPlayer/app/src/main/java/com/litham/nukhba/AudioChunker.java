package com.litham.nukhba;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/** Extracts AAC sound without uploading video frames. Native remuxing is fast and lossless.
 *  Unsupported audio codecs need a transcoder in a later version. */
final class AudioChunker {
    static final class Part {
        final File file;
        final long startUs;
        Part(File file, long startUs) { this.file = file; this.startUs = startUs; }
    }
    static List<Part> split(Context ctx, Uri videoUri, File workDir) throws IOException {
        if (!workDir.exists() && !workDir.mkdirs()) throw new IOException("تعذر إنشاء مجلد مؤقت");
        MediaExtractor extractor = new MediaExtractor();
        List<Part> result = new ArrayList<>();
        MediaMuxer muxer = null;
        try {
            extractor.setDataSource(ctx, videoUri, null);
            int sourceTrack = -1;
            MediaFormat format = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    sourceTrack = i;
                    format = f;
                    break;
                }
            }
            if (sourceTrack < 0 || format == null) throw new IOException("الفيديو لا يحتوي على مسار صوتي");
            String codec = format.getString(MediaFormat.KEY_MIME);
            if (!"audio/mp4a-latm".equals(codec)) {
                throw new IOException("صيغة الصوت " + codec + " غير مدعومة لاستخراج الترجمة حالياً. جرّب ملف MP4 بصوت AAC.");
            }
            extractor.selectTrack(sourceTrack);
            ByteBuffer buffer = ByteBuffer.allocateDirect(4 * 1024 * 1024);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            long baseUs = -1;
            int destTrack = -1;
            long partSize = 0;
            int partNumber = 0;
            while (!Thread.currentThread().isInterrupted()) {
                buffer.clear();
                int size = extractor.readSampleData(buffer, 0);
                if (size < 0) break;
                long sampleUs = extractor.getSampleTime();
                if (sampleUs < 0) break;
                if (muxer == null || (baseUs >= 0 && sampleUs - baseUs >= 150_000_000L)
                        || partSize + size > 18_000_000L) {
                    if (muxer != null) {
                        muxer.stop();
                        muxer.release();
                        muxer = null;
                    }
                    baseUs = sampleUs;
                    File file = new File(workDir, String.format(java.util.Locale.US, "audio_%04d.m4a", partNumber++));
                    muxer = new MediaMuxer(file.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                    destTrack = muxer.addTrack(format);
                    muxer.start();
                    result.add(new Part(file, baseUs));
                    partSize = 0;
                }
                info.offset = 0;
                info.size = size;
                info.presentationTimeUs = Math.max(0, sampleUs - baseUs);
                info.flags = extractor.getSampleFlags();
                buffer.position(0);
                buffer.limit(size);
                muxer.writeSampleData(destTrack, buffer, info);
                partSize += size;
                extractor.advance();
            }
            if (Thread.currentThread().isInterrupted()) throw new IOException("أُلغيت العملية");
            if (muxer != null) { muxer.stop(); muxer.release(); muxer = null; }
            if (result.isEmpty()) throw new IOException("تعذر استخراج الصوت من هذا الفيلم");
            return result;
        } finally {
            if (muxer != null) { try { muxer.stop(); } catch (Exception ignored) {} try { muxer.release(); } catch (Exception ignored) {} }
            extractor.release();
        }
    }
}
