$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
$sdk = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } elseif ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (!(Test-Path (Join-Path $sdk 'platforms\android-35\android.jar'))) {
  Write-Host 'Android SDK Platform 35 not found. Open Android Studio > SDK Manager and install Android API 35 first.' -ForegroundColor Yellow
  exit 1
}
$env:ANDROID_HOME = $sdk
$env:ANDROID_SDK_ROOT = $sdk
if (!$env:JAVA_HOME -and (Test-Path (Join-Path $env:ProgramFiles 'Android\Android Studio\jbr\bin\java.exe'))) {
  $env:JAVA_HOME = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
  $env:PATH = (Join-Path $env:JAVA_HOME 'bin') + ';' + $env:PATH
}
$home = Join-Path $env:LOCALAPPDATA 'NukhbaGradle'
$gradle = Join-Path $home 'gradle-8.11.1\bin\gradle.bat'
if (!(Test-Path $gradle)) {
  New-Item -ItemType Directory -Force -Path $home | Out-Null
  $archive = Join-Path $home 'gradle-8.11.1-bin.zip'
  Write-Host 'Downloading official Gradle 8.11.1 (requires Internet)...'
  Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.11.1-bin.zip' -OutFile $archive
  Expand-Archive -Path $archive -DestinationPath $home -Force
  Remove-Item $archive
}
Write-Host 'Building Android APK (Internet needed on first build)...'
& $gradle -p $project --no-daemon assembleDebug
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$apk = Join-Path $project 'app\build\outputs\apk\debug\app-debug.apk'
$dest = Join-Path $project 'NukhbaArabicPlayer-debug.apk'
Copy-Item -Force $apk $dest
Write-Host "APK ready: $dest" -ForegroundColor Green
