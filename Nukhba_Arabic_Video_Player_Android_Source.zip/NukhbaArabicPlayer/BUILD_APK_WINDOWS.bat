@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_apk_windows.ps1"
if errorlevel 1 (
 echo.
 echo BUILD FAILED - see the message above.
 pause
 exit /b 1
)
echo.
echo APK created successfully.
pause
